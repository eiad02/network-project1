package TCPClient;
import java.io.*;
import java.net.*;

public class TCPClient {
	public static void main (String[]args)throws Exception{
		//Java Client 
		String sentence ;
		String modifiedSentence ;
		//create input stream 
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		// create client socket connect to server .
		//if(inFromUser.equals("CONNECT")){
		Socket clientSocket =new Socket("172.20.10.3",1999); //localAddress is the IP address of the server ::: 3000 is the port number of the server
		// the socket client is the process that responsible for create connection 
		System.out.println("connected!!");
		// create output stream attached to socket 
		DataOutputStream outToServer= new DataOutputStream(clientSocket.getOutputStream());
		// create input stream attached to socket
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		
		sentence = inFromUser.readLine();
		//send line to server
		outToServer.writeBytes(sentence + '\n'); 
		 
		modifiedSentence =inFromServer.readLine() ;
		//printing the sentence from the Server 
		System.out.println("FROM SERVER"+ modifiedSentence );
		clientSocket.close();
				

	}
	}


