package TCPServer;
import java.io.*; 
import java.net.*;

public class TCPServer {
	public static void main(String[]args)throws Exception{
	      String clientSentence; 
	      String capitalizedSentence ;
	      //getting the IP address of the server 
	      System.out.println( InetAddress.getLocalHost());
	      //create welcoming socket at port 3000
	      ServerSocket welcomeSocket = new ServerSocket(1999); //indicate a port number to the server 
	      //wait,till the socket connect with the client 
    	  Socket connectionSocket = welcomeSocket.accept();
    	  System.out.println("connected");
    	  //create input stream attached to socket
    	  BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
    	  //here you get the input from the client by getting the input stream that had came at connection socket 
	      while(true){
	    	  //create output stream attached to the socket 
	    	  DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
	    	  // read in line from socket 
	    	  clientSentence = inFromClient.readLine();
	    	  //printing the input from the client 
	    	  System.out.println(clientSentence);
	    	  capitalizedSentence = clientSentence.toUpperCase()+'\n';
	    	  // write out line to socket 
	    	  outToClient.writeBytes(capitalizedSentence);
	      }
		
	}

}
/*
 * netstat -a -o -n
 * taskkill /f /PID num 
 */
